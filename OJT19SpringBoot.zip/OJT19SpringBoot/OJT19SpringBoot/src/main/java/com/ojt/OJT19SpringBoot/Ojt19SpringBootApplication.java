package com.ojt.OJT19SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ojt19SpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ojt19SpringBootApplication.class, args);
	}

}
