package com.ojt.OJT19SpringBoot.entity;

public enum UserRole {
    SUPERADMIN,ADMIN,USER;
}
