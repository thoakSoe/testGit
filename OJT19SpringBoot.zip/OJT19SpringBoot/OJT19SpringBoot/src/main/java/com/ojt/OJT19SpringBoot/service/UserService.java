package com.ojt.OJT19SpringBoot.service;

import com.ojt.OJT19SpringBoot.dto.UserDTO;

public interface UserService {
    public UserDTO saveUser(UserDTO user);
}
