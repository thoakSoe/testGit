package com.ojt.OJT19SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ojt19SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
